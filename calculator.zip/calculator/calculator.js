class Calculator {
    constructor() {
        this.clear();
    }

    clear() {
        this.operand1 = "";
        this.operand2 = "";
        this.operator = "";
        this.decimalUsed = false;
    }

    appendNumber(number) {
        if (this.operator === "") {
            this.operand1 += number.toString();
        } else {
            this.operand2 += number.toString();
        }
    }

    toggleSign() {
        if (this.operator === "") {
            this.operand1 = -1 * parseFloat(this.operand1);
        } else {
            this.operand2 = -1 * parseFloat(this.operand2);
        }
    }

    decimal() {
        if (this.operator === "" && !this.decimalUsed) {
            this.operand1 += ".";
            this.decimalUsed = true;
        } else if (this.operator !== "" && !this.decimalUsed) {
            this.operand2 += ".";
            this.decimalUsed = true;
        }
    }

    setOperator(operator) {
        if (this.operator === "") {
            this.operator = operator;
        } else {
            this.calculate();
            this.operator = operator;
        }
    }

    calculate() {
        let result;
        const operand1 = parseFloat(this.operand1);
        const operand2 = parseFloat(this.operand2);

        switch (this.operator) {
            case "+":
                result = operand1 + operand2;
                break;
            case "-":
                result = operand1 - operand2;
                break;
            case "*":
                result = operand1 * operand2;
                break;
            case "/":
                result = operand1 / operand2;
                break;
            default:
                return;
        }

        this.operand1 = result.toString();
        this.operand2 = "";
        this.operator = "";
        this.decimalUsed = false;
    }

    convertToBinary() {
        const decimalValue = parseFloat(this.operand1);
        const binaryValue = decimalValue.toString(2);
        this.clear();
        this.operand1 = binaryValue;
        this.display();
    }

    convertToOctal() {
        const decimalValue = parseFloat(this.operand1);
        const octalValue = decimalValue.toString(8);
        this.clear();
        this.operand1 = octalValue;
        this.display();
    }

    convertToDecimal() {
        const hexValue = this.operand1;
        const decimalValue = parseInt(hexValue, 16);
        this.clear();
        this.operand1 = decimalValue.toString();
        this.display();
    }

    convertToHexadecimal() {
        const decimalValue = parseFloat(this.operand1);
        const hexValue = decimalValue.toString(16).toUpperCase();
        this.clear();
        this.operand1 = hexValue;
        this.display();
    }

    clearEntry() {
        if (this.operator === "") {
            this.operand1 = this.operand1.slice(0, -1); 
        } else {
            this.operand2 = this.operand2.slice(0, -1); 
        }
        this.display();
    }

    clearDisplay() {
        this.clear();
        this.display();
    }

    display() {
        const display = document.querySelector(".display");
        display.value = this.operand1 + " " + this.operator + " " + this.operand2;
    }
}

const calculator = new Calculator();

function clearDisplay() {
    calculator.clearDisplay();
}

function clearEntry() {
    calculator.clearEntry();
}

function toggleSign() {
    calculator.toggleSign();
    calculator.display();
}

function percent() {
    calculator.operand2 = parseFloat(calculator.operand2) / 100;
    calculator.display();
}

function divide() {
    calculator.setOperator("/");
    calculator.display();
}

function multiply() {
    calculator.setOperator("*");
    calculator.display();
}

function subtract() {
    calculator.setOperator("-");
    calculator.display();
}

function add() {
    calculator.setOperator("+");
    calculator.display();
}

function appendNumber(number) {
    calculator.appendNumber(number);
    calculator.display();
}

function decimal() {
    calculator.decimal();
    calculator.display();
}

function calculate() {
    calculator.calculate();
    calculator.display();
}

function convertToBinary() {
    calculator.convertToBinary();
}

function convertToOctal() {
    calculator.convertToOctal();
}

function convertToDecimal() {
    calculator.convertToDecimal();
}

function convertToHexadecimal() {
    calculator.convertToHexadecimal();
}
